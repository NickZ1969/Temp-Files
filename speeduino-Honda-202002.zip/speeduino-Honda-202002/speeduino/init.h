#ifndef INIT_H
#define INIT_H

void initialiseAll();
void initialiseTriggers();
void setPinMapping(byte);

#endif